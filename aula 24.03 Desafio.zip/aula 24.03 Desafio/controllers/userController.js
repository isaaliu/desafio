const User = require('../models/userModel');
//Esta linha exporta a função para que ela possa ser usada em outras partes do aplicativo
exports.getAllUsers = (req, res) => {
    // Esta linha chama uma função 
    User.getAllUsers((users) => {
        //Depois que os dados do usuário são recuperados, o método é usado para renderizar a exibição.
        res.render('index', { users });
    });
};

exports.getUserById = (req, res) => {
    const userId = req.params.id_pet;
    User.getUserById(userId, (user) => {
        res.render('edit', { user });
    });
};

///exibir usuário antes de deletar 
exports.getdeleteByUser = (req, res) => {
    const userId = req.params.id_pet;
    User.getUserById(userId, (user) => {
        res.render('dell', { user });
    });
};

exports.addUser = (req, res) => {
    const newUser = {
        name: req.body.name,
        especie: req.body.especie,
        raca: req.body.raca,
        porte: req.body.porte,
        cor: req.body.cor


    };
    User.addUser(newUser, () => {
        res.redirect('/');
    });
};

exports.updateUser = (req, res) => {
    const userId = req.params.id_pet;
    const updatedUser = {
        name: req.body.name,
        especie: req.body.especie,
        raca: req.body.raca,
        porte: req.body.porte,
        cor: req.body.cor

    };
    User.updateUser(userId, updatedUser, () => {
        res.redirect('/');
    });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.id_pet;
    User.deleteUser(userId, () => {
        res.redirect('/');
    });
};



